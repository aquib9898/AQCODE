import { createContext } from "react";

export const NewsContext = createContext();

export const NewsContextProvider = NewsContext.Provider;
